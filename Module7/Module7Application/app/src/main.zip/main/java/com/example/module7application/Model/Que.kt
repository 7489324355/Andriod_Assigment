package com.example.module7application.Model

data class Que(
    var id:Int,
    var name:String
)